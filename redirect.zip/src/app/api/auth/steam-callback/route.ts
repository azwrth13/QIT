import { PrismaClient } from '@prisma/client';
import { NextResponse } from 'next/server';
import fetch from 'node-fetch';

const prisma = new PrismaClient();
const STEAM_API_KEY = process.env.STEAM_API_KEY;

interface SteamProfileResponse {
  response: {
    players: {
      steamid: string;
      profileurl: string;
      avatarfull: string;
      personaname: string;
    }[];
  };
}

export async function GET(req: Request) {
  const url = new URL(req.url);
  const params = new URLSearchParams(url.search);

  // Add OpenID check_authentication
  params.set('openid.mode', 'check_authentication');
  const verifyUrl = 'https://steamcommunity.com/openid/login';

  const response = await fetch(verifyUrl, {
    method: 'POST',
    body: params,
  });

  const body = await response.text();

  if (!body.includes('is_valid:true')) {
    return NextResponse.json({ error: 'Invalid login attempt' }, { status: 401 });
  }

  const steamIdMatch = params.get('openid.claimed_id')?.match(/\d+$/);
  const steamId = steamIdMatch ? steamIdMatch[0] : null;

  if (!steamId) {
    return NextResponse.json({ error: 'Unable to retrieve Steam ID' }, { status: 400 });
  }

  const profileUrl = `https://api.steampowered.com/ISteamUser/GetPlayerSummaries/v2/?key=${STEAM_API_KEY}&steamids=${steamId}`;
  const profileRes = await fetch(profileUrl);
  const profileData = (await profileRes.json()) as SteamProfileResponse;

  const profile = profileData.response.players[0];
  if (!profile) {
    return NextResponse.json({ error: 'Profile not found' }, { status: 404 });
  }

  const user = await prisma.user.upsert({
    where: { steamId },
    update: { profileUrl: profile.profileurl },
    create: {
      steamId,
      profileUrl: profile.profileurl,
    },
  });

  // Generate an absolute URL for redirection
  const redirectUrl = new URL('/', req.url);
  redirectUrl.searchParams.set('success', 'true');
  redirectUrl.searchParams.set('user', user.id.toString());

  return NextResponse.redirect(redirectUrl.toString());
}
