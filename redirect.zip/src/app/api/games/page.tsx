'use client';
import { useEffect, useState } from 'react';
import { SteamGame } from '../../../../types/steam';

const GamesPage = () => {
    const [steamId, setSteamId] = useState<string | null>(null);
    const [games, setGames] = useState<SteamGame[]>([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        const fetchSteamId = async () => {
            try {
                const response = await fetch('/api/getSteamId');
                const data = await response.json();
                setSteamId(data.steamId);
            } catch (error) {
                console.error('Error fetching Steam ID:', error);
            }
        };

        fetchSteamId();
    }, []);

    useEffect(() => {
        const fetchGames = async () => {
            if (steamId) {
                try {
                    const response = await fetch(`/api/games/getUserGames?steamId=${steamId}`);
                    const data = await response.json();
                    setGames(data.games || []);
                } catch (error) {
                    console.error('Error fetching games:', error);
                } finally {
                    setLoading(false);
                }
            }
        };

        fetchGames();
    }, [steamId]);

    if (loading) return <p>Loading games...</p>;

    return (
        <div>
            <h1>Your Steam Library</h1>
            <ul>
                {games.map((game) => (
                    <li key={game.appid}>
                        <img
                            src={`http://media.steampowered.com/steamcommunity/public/images/apps/${game.appid}/${game.img_icon_url}.jpg`}
                            alt={game.name}
                        />
                        <p>{game.name}</p>
                        <p>Playtime: {game.playtime_forever} minutes</p>
                    </li>
                ))}
            </ul>
        </div>
    );
};

export default GamesPage;
