// app/api/games/route.ts
import prisma from '../../library/prisma';
import { NextResponse } from 'next/server';
import { SteamOwnedGamesResponse, SteamGame } from '../../../../types/steam';

const STEAM_API_KEY = process.env.STEAM_API_KEY;

if (!STEAM_API_KEY) {
  throw new Error('STEAM_API_KEY is not defined in the environment variables.');
}

// Utility function for SteamID validation
const isValidSteamId = (steamId: string): boolean => {
  const steamIdRegex = /^\\d{17}$/;
  return steamIdRegex.test(steamId);
};

// POST Handler: Fetch and store games
export async function POST(req: Request) {
  try {
    const { steamId } = await req.json();

    if (!steamId || typeof steamId !== 'string' || !isValidSteamId(steamId)) {
      return NextResponse.json({ error: 'Invalid or missing Steam ID' }, { status: 400 });
    }

    // Fetch or create the user
    const user = await prisma.user.upsert({
      where: { steamId },
      update: {},
      create: {
        steamId,
        profileUrl: `https://steamcommunity.com/profiles/${steamId}`,
      },
    });

    // Fetch owned games from Steam API
    const response = await fetch(
      `https://api.steampowered.com/IPlayerService/GetOwnedGames/v1/?key=${STEAM_API_KEY}&steamid=${steamId}&include_appinfo=true&include_played_free_games=true`
    );

    if (!response.ok) {
      console.error('Steam API response error:', response.statusText);
      throw new Error('Steam API request failed');
    }

    const data: SteamOwnedGamesResponse = await response.json();

    if (data && data.response && Array.isArray(data.response.games)) {
      // Map games to match the Game model structure
      const gamesData = data.response.games.map((game: SteamGame) => ({
        appid: game.appid,
        name: game.name,
        playtime_2weeks: game.playtime_2weeks || 0,
        playtime_forever: game.playtime_forever || 0,
        img_icon_url: game.img_icon_url || null,
        img_logo_url: game.img_logo_url || null,
        userId: user.id,
      }));

      // Insert games into the database
      await prisma.game.createMany({
        data: gamesData,
        skipDuplicates: true,
      });

      return NextResponse.json({ games: gamesData });
    }

    return NextResponse.json({ error: 'No games found or available' });
  } catch (error) {
    console.error('Error in fetching games:', error);
    return NextResponse.json({ error: 'Failed to fetch games' }, { status: 500 });
  }
}
